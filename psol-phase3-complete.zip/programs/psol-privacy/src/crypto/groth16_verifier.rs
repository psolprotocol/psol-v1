//! Groth16 Zero-Knowledge Proof Verifier - Phase 3
//!
//! Production-ready Groth16 verification for the pSol privacy pool.
//! Uses Solana's alt_bn128 precompiles for efficient pairing operations.
//!
//! # Phase 3 Changes
//! - Removed unsafe dev-mode bypass from production code
//! - Test-only bypass available via `#[cfg(test)]`
//! - All verification is cryptographically enforced
//!
//! # Verification Equation
//! The Groth16 verification equation is:
//! ```text
//! e(A, B) = e(α, β) · e(vk_x, γ) · e(C, δ)
//! ```
//!
//! Rewritten as a single pairing check:
//! ```text
//! e(-A, B) · e(α, β) · e(vk_x, γ) · e(C, δ) = 1
//! ```
//!
//! Where:
//! - (A, B, C) are the proof elements
//! - (α, β, γ, δ) are from the verification key
//! - vk_x = IC[0] + Σ(public_input[i] · IC[i+1])
//!
//! # Security
//! - Invalid proofs are ALWAYS rejected
//! - All curve points are validated before use
//! - Verification key must come from trusted setup

use anchor_lang::prelude::*;

use crate::error::PrivacyError;
use crate::state::verification_key::VerificationKey;

use super::curve_utils::{
    compute_vk_x, is_g1_identity, is_g2_identity, make_pairing_element,
    negate_g1, validate_g1_point, validate_g2_point, verify_pairing,
    G1Point, G2Point, PairingElement,
};
use super::public_inputs::ZkPublicInputs;

// ============================================================================
// CONSTANTS
// ============================================================================

/// Expected proof data length in bytes.
/// A = 64 bytes (G1 uncompressed)
/// B = 128 bytes (G2 uncompressed)
/// C = 64 bytes (G1 uncompressed)
pub const PROOF_DATA_LEN: usize = 256;

// ============================================================================
// PROOF STRUCTURE
// ============================================================================

/// Groth16 proof structure.
///
/// A Groth16 proof consists of three curve points: (A, B, C)
/// where A, C ∈ G1 and B ∈ G2.
///
/// ## Encoding
/// All points are in uncompressed big-endian format:
/// - G1 points: 64 bytes (32 bytes x, 32 bytes y)
/// - G2 points: 128 bytes (64 bytes x, 64 bytes y)
#[derive(Clone, Debug)]
pub struct Groth16Proof {
    /// Point A ∈ G1 (uncompressed, 64 bytes)
    pub a: G1Point,
    
    /// Point B ∈ G2 (uncompressed, 128 bytes)
    pub b: G2Point,
    
    /// Point C ∈ G1 (uncompressed, 64 bytes)
    pub c: G1Point,
}

impl Groth16Proof {
    /// Parse proof from raw bytes.
    ///
    /// # Arguments
    /// * `data` - Raw proof bytes (256 bytes expected)
    ///
    /// # Returns
    /// Parsed proof structure or error
    ///
    /// # Layout
    /// ```text
    /// [0..64]    - A (G1 point)
    /// [64..192]  - B (G2 point)
    /// [192..256] - C (G1 point)
    /// ```
    pub fn from_bytes(data: &[u8]) -> Result<Self> {
        if data.len() != PROOF_DATA_LEN {
            msg!("Invalid proof length: {} (expected {})", data.len(), PROOF_DATA_LEN);
            return Err(error!(PrivacyError::InvalidProofFormat));
        }

        let mut proof = Groth16Proof {
            a: [0u8; 64],
            b: [0u8; 128],
            c: [0u8; 64],
        };

        proof.a.copy_from_slice(&data[0..64]);
        proof.b.copy_from_slice(&data[64..192]);
        proof.c.copy_from_slice(&data[192..256]);

        Ok(proof)
    }

    /// Serialize proof to bytes.
    pub fn to_bytes(&self) -> [u8; PROOF_DATA_LEN] {
        let mut bytes = [0u8; PROOF_DATA_LEN];
        bytes[0..64].copy_from_slice(&self.a);
        bytes[64..192].copy_from_slice(&self.b);
        bytes[192..256].copy_from_slice(&self.c);
        bytes
    }
}

// ============================================================================
// VERIFICATION FUNCTION
// ============================================================================

/// Verify a Groth16 zero-knowledge proof.
///
/// # Algorithm
/// 1. Parse and validate proof points
/// 2. Validate verification key structure
/// 3. Encode public inputs as field elements
/// 4. Compute vk_x = IC[0] + Σ(public_input[i] · IC[i+1])
/// 5. Compute pairing: e(-A, B) · e(α, β) · e(vk_x, γ) · e(C, δ) = 1
///
/// # Arguments
/// * `proof_bytes` - Raw proof data (256 bytes)
/// * `vk` - Verification key from trusted setup
/// * `public_inputs` - Public inputs to the circuit
///
/// # Returns
/// * `Ok(true)` - Proof is valid
/// * `Ok(false)` - Proof is invalid (pairing check failed)
/// * `Err(...)` - Verification error (malformed inputs)
///
/// # Security
/// - This function is cryptographically critical
/// - Invalid proofs MUST always be rejected
/// - The verification key must come from a trusted setup
/// - NO bypass is available in production builds
pub fn verify_groth16_proof(
    proof_bytes: &[u8],
    vk: &VerificationKey,
    public_inputs: &ZkPublicInputs,
) -> Result<bool> {
    // In test builds, allow bypass for unit testing
    #[cfg(test)]
    {
        if is_test_bypass_enabled() {
            msg!("⚠️ TEST MODE: Proof verification bypassed");
            return Ok(true);
        }
    }

    // Production verification - always cryptographically enforced
    verify_groth16_proof_impl(proof_bytes, vk, public_inputs)
}

/// Internal implementation of Groth16 verification.
///
/// Performs the full cryptographic verification.
fn verify_groth16_proof_impl(
    proof_bytes: &[u8],
    vk: &VerificationKey,
    public_inputs: &ZkPublicInputs,
) -> Result<bool> {
    msg!("Groth16 verification starting...");

    // Step 1: Parse proof structure
    let proof = Groth16Proof::from_bytes(proof_bytes)?;
    msg!("Step 1/8: Proof parsed");

    // Step 2: Validate proof points are on curve and not identity
    validate_proof_points(&proof)?;
    msg!("Step 2/8: Proof points validated");

    // Step 3: Validate VK is properly configured
    validate_verification_key(vk)?;
    msg!("Step 3/8: Verification key validated");

    // Step 4: Validate and encode public inputs
    public_inputs.validate()?;
    let encoded_inputs = public_inputs.to_field_elements();
    msg!("Step 4/8: {} public inputs encoded", encoded_inputs.len());

    // Step 5: Compute vk_x = IC[0] + Σ(input[i] * IC[i+1])
    let vk_x = compute_vk_x(&vk.ic, &encoded_inputs)?;
    msg!("Step 5/8: vk_x computed");

    // Step 6: Negate A for pairing equation
    let neg_a = negate_g1(&proof.a)?;
    msg!("Step 6/8: A negated");

    // Step 7: Construct pairing elements
    // Verification equation: e(-A, B) · e(α, β) · e(vk_x, γ) · e(C, δ) = 1
    let pairing_elements: [PairingElement; 4] = [
        make_pairing_element(&neg_a, &proof.b),           // e(-A, B)
        make_pairing_element(&vk.alpha_g1, &vk.beta_g2),  // e(α, β)
        make_pairing_element(&vk_x, &vk.gamma_g2),        // e(vk_x, γ)
        make_pairing_element(&proof.c, &vk.delta_g2),     // e(C, δ)
    ];
    msg!("Step 7/8: Pairing elements constructed");

    // Step 8: Verify pairing
    msg!("Step 8/8: Performing pairing check...");
    let result = verify_pairing(&pairing_elements)?;

    if result {
        msg!("✓ Proof verified successfully");
    } else {
        msg!("✗ Proof verification FAILED");
    }

    Ok(result)
}

// ============================================================================
// VALIDATION HELPERS
// ============================================================================

/// Validate that proof points are well-formed.
///
/// Checks:
/// 1. A ∈ G1 is not identity and on curve
/// 2. B ∈ G2 is not identity and valid
/// 3. C ∈ G1 is not identity and on curve
fn validate_proof_points(proof: &Groth16Proof) -> Result<()> {
    // Check A is not identity
    if is_g1_identity(&proof.a) {
        msg!("Proof point A is identity (invalid)");
        return Err(error!(PrivacyError::InvalidProof));
    }
    
    // Validate A is on curve
    validate_g1_point(&proof.a).map_err(|_| {
        msg!("Proof point A is not on curve");
        error!(PrivacyError::InvalidProof)
    })?;

    // Check B is not identity
    if is_g2_identity(&proof.b) {
        msg!("Proof point B is identity (invalid)");
        return Err(error!(PrivacyError::InvalidProof));
    }
    
    // Validate B
    validate_g2_point(&proof.b).map_err(|_| {
        msg!("Proof point B validation failed");
        error!(PrivacyError::InvalidProof)
    })?;

    // Check C is not identity
    if is_g1_identity(&proof.c) {
        msg!("Proof point C is identity (invalid)");
        return Err(error!(PrivacyError::InvalidProof));
    }
    
    // Validate C is on curve
    validate_g1_point(&proof.c).map_err(|_| {
        msg!("Proof point C is not on curve");
        error!(PrivacyError::InvalidProof)
    })?;

    Ok(())
}

/// Validate verification key structure and values.
///
/// Checks:
/// 1. Sufficient IC points for public inputs
/// 2. Alpha is not identity and on curve
/// 3. All VK points are valid
fn validate_verification_key(vk: &VerificationKey) -> Result<()> {
    // Must have at least 2 IC points (1 base + 1 for at least 1 public input)
    if vk.ic.len() < 2 {
        msg!("VK has insufficient IC points: {} (need at least 2)", vk.ic.len());
        return Err(error!(PrivacyError::VerificationKeyNotSet));
    }

    // For withdrawal circuit with 6 public inputs, we need 7 IC points
    if vk.ic.len() != ZkPublicInputs::COUNT + 1 {
        msg!(
            "VK IC length mismatch: {} (expected {})",
            vk.ic.len(),
            ZkPublicInputs::COUNT + 1
        );
        return Err(error!(PrivacyError::InvalidPublicInputs));
    }

    // Alpha must not be identity
    if is_g1_identity(&vk.alpha_g1) {
        msg!("VK alpha is identity (invalid)");
        return Err(error!(PrivacyError::VerificationKeyNotSet));
    }

    // Validate alpha is on curve
    validate_g1_point(&vk.alpha_g1).map_err(|_| {
        msg!("VK alpha is not on curve");
        error!(PrivacyError::VerificationKeyNotSet)
    })?;

    // Validate G2 points
    validate_g2_point(&vk.beta_g2).map_err(|_| {
        msg!("VK beta is invalid");
        error!(PrivacyError::VerificationKeyNotSet)
    })?;
    
    validate_g2_point(&vk.gamma_g2).map_err(|_| {
        msg!("VK gamma is invalid");
        error!(PrivacyError::VerificationKeyNotSet)
    })?;
    
    validate_g2_point(&vk.delta_g2).map_err(|_| {
        msg!("VK delta is invalid");
        error!(PrivacyError::VerificationKeyNotSet)
    })?;

    // Validate each IC point
    for (i, ic_point) in vk.ic.iter().enumerate() {
        validate_g1_point(ic_point).map_err(|_| {
            msg!("VK IC[{}] is not on curve", i);
            error!(PrivacyError::VerificationKeyNotSet)
        })?;
    }

    Ok(())
}

// ============================================================================
// TEST UTILITIES
// ============================================================================

/// Test-only bypass flag
#[cfg(test)]
static TEST_BYPASS: std::sync::atomic::AtomicBool = std::sync::atomic::AtomicBool::new(false);

/// Check if test bypass is enabled
#[cfg(test)]
fn is_test_bypass_enabled() -> bool {
    TEST_BYPASS.load(std::sync::atomic::Ordering::Relaxed)
}

/// Enable test bypass (for unit tests only)
#[cfg(test)]
pub fn enable_test_bypass() {
    TEST_BYPASS.store(true, std::sync::atomic::Ordering::Relaxed);
}

/// Disable test bypass
#[cfg(test)]
pub fn disable_test_bypass() {
    TEST_BYPASS.store(false, std::sync::atomic::Ordering::Relaxed);
}

// ============================================================================
// TESTS
// ============================================================================

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_proof_parsing() {
        let data = [1u8; PROOF_DATA_LEN];
        let proof = Groth16Proof::from_bytes(&data).unwrap();
        
        assert_eq!(proof.a, [1u8; 64]);
        assert_eq!(proof.b, [1u8; 128]);
        assert_eq!(proof.c, [1u8; 64]);
    }

    #[test]
    fn test_proof_roundtrip() {
        let data = [42u8; PROOF_DATA_LEN];
        let proof = Groth16Proof::from_bytes(&data).unwrap();
        let back = proof.to_bytes();
        
        assert_eq!(data, back);
    }

    #[test]
    fn test_invalid_proof_length_short() {
        let data = [1u8; 100]; // Too short
        let result = Groth16Proof::from_bytes(&data);
        
        assert!(result.is_err());
    }

    #[test]
    fn test_invalid_proof_length_long() {
        let data = [1u8; 300]; // Too long
        let result = Groth16Proof::from_bytes(&data);
        
        assert!(result.is_err());
    }

    #[test]
    fn test_empty_proof() {
        let data: [u8; 0] = [];
        let result = Groth16Proof::from_bytes(&data);
        
        assert!(result.is_err());
    }

    #[test]
    fn test_proof_with_distinct_parts() {
        let mut data = [0u8; PROOF_DATA_LEN];
        
        // Fill A with 1s
        for i in 0..64 {
            data[i] = 1;
        }
        // Fill B with 2s
        for i in 64..192 {
            data[i] = 2;
        }
        // Fill C with 3s
        for i in 192..256 {
            data[i] = 3;
        }

        let proof = Groth16Proof::from_bytes(&data).unwrap();
        
        assert!(proof.a.iter().all(|&b| b == 1));
        assert!(proof.b.iter().all(|&b| b == 2));
        assert!(proof.c.iter().all(|&b| b == 3));
    }

    #[test]
    fn test_bypass_flag() {
        // Initially disabled
        assert!(!is_test_bypass_enabled());
        
        // Enable
        enable_test_bypass();
        assert!(is_test_bypass_enabled());
        
        // Disable
        disable_test_bypass();
        assert!(!is_test_bypass_enabled());
    }
}
