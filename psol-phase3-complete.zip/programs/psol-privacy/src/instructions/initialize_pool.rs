//! Initialize Pool Instruction - Phase 3
//!
//! Creates a new privacy pool for a specific SPL token.
//!
//! # Created Accounts
//! - PoolConfig PDA (pool settings)
//! - MerkleTree PDA (commitment storage)
//! - VerificationKeyAccount PDA (Groth16 VK)
//! - Vault token account (holds deposited tokens)

use anchor_lang::prelude::*;
use anchor_spl::token::{Mint, Token, TokenAccount};

use crate::error::PrivacyError;
use crate::events::PoolInitialized;
use crate::state::{MerkleTree, PoolConfig, VerificationKeyAccount};

/// Accounts for initialize_pool instruction.
#[derive(Accounts)]
#[instruction(tree_depth: u8, root_history_size: u16)]
pub struct InitializePool<'info> {
    /// Pool configuration account (created).
    #[account(
        init,
        payer = authority,
        space = PoolConfig::LEN,
        seeds = [b"pool", token_mint.key().as_ref()],
        bump
    )]
    pub pool_config: Account<'info, PoolConfig>,

    /// Merkle tree account (created).
    #[account(
        init,
        payer = authority,
        space = MerkleTree::space(tree_depth, root_history_size),
        seeds = [b"merkle_tree", pool_config.key().as_ref()],
        bump
    )]
    pub merkle_tree: Account<'info, MerkleTree>,

    /// Verification key account (created).
    #[account(
        init,
        payer = authority,
        space = VerificationKeyAccount::space(VerificationKeyAccount::DEFAULT_MAX_IC_POINTS),
        seeds = [b"verification_key", pool_config.key().as_ref()],
        bump
    )]
    pub verification_key: Account<'info, VerificationKeyAccount>,

    /// Token vault account (created).
    #[account(
        init,
        payer = authority,
        token::mint = token_mint,
        token::authority = pool_config,
        seeds = [b"vault", pool_config.key().as_ref()],
        bump
    )]
    pub vault: Account<'info, TokenAccount>,

    /// SPL token mint for this pool.
    pub token_mint: Account<'info, Mint>,

    /// Pool authority (becomes admin, pays for account creation).
    #[account(mut)]
    pub authority: Signer<'info>,

    /// Token program.
    pub token_program: Program<'info, Token>,

    /// System program.
    pub system_program: Program<'info, System>,

    /// Rent sysvar.
    pub rent: Sysvar<'info, Rent>,
}

/// Handler for initialize_pool instruction.
///
/// # Arguments
/// * `tree_depth` - Merkle tree depth (4-24)
/// * `root_history_size` - Number of historical roots to store (min 30)
///
/// # Recommended Parameters
/// - tree_depth: 20 (supports ~1M leaves)
/// - root_history_size: 100 (100 historical roots)
pub fn handler(
    ctx: Context<InitializePool>,
    tree_depth: u8,
    root_history_size: u16,
) -> Result<()> {
    // Validate parameters
    require!(
        tree_depth >= 4 && tree_depth <= 24,
        PrivacyError::InvalidTreeDepth
    );
    require!(
        root_history_size >= 30,
        PrivacyError::InvalidRootHistorySize
    );

    msg!("Initializing privacy pool...");
    msg!("Tree depth: {}", tree_depth);
    msg!("Root history size: {}", root_history_size);

    // Initialize pool config
    let pool_config = &mut ctx.accounts.pool_config;
    pool_config.initialize(
        ctx.accounts.authority.key(),
        ctx.accounts.token_mint.key(),
        ctx.accounts.vault.key(),
        ctx.accounts.merkle_tree.key(),
        ctx.accounts.verification_key.key(),
        tree_depth,
        ctx.bumps.pool_config,
    );

    // Initialize Merkle tree
    let merkle_tree = &mut ctx.accounts.merkle_tree;
    merkle_tree.initialize(
        pool_config.key(),
        tree_depth,
        root_history_size,
    )?;

    // Initialize verification key (empty, to be set later)
    let verification_key = &mut ctx.accounts.verification_key;
    verification_key.initialize(
        pool_config.key(),
        ctx.bumps.verification_key,
    );

    // Emit event
    emit!(PoolInitialized {
        pool: pool_config.key(),
        authority: ctx.accounts.authority.key(),
        token_mint: ctx.accounts.token_mint.key(),
        tree_depth,
        root_history_size,
        timestamp: Clock::get()?.unix_timestamp,
    });

    msg!("Pool initialized successfully");
    msg!("Pool: {}", pool_config.key());
    msg!("Vault: {}", ctx.accounts.vault.key());
    msg!("Tree capacity: {} leaves", 1u32 << tree_depth);

    Ok(())
}
