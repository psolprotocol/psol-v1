//! Instruction Handlers for pSol Privacy Pool - Phase 3
//!
//! # Instructions
//!
//! ## Core Operations
//! - `deposit` - Deposit tokens with pre-computed commitment
//! - `withdraw` - Withdraw tokens with ZK proof
//! - `private_transfer` - 2-in-2-out transfer within pool
//!
//! ## Setup
//! - `initialize_pool` - Create new privacy pool
//! - `set_verification_key` - Configure Groth16 VK
//!
//! ## Admin
//! - `pause_pool` / `unpause_pool` - Emergency controls
//! - `update_authority` - Transfer admin rights
//!
//! # Phase 3 Changes
//! - Deposit now takes pre-computed commitment (not secret/nullifier)
//! - Private transfer is fully implemented (2-in-2-out)
//! - All instructions use proper named exports

pub mod admin;
pub mod deposit;
pub mod initialize_pool;
pub mod private_transfer;
pub mod set_verification_key;
pub mod withdraw;

// Re-export instruction account structs
pub use deposit::Deposit;
pub use initialize_pool::InitializePool;
pub use private_transfer::PrivateTransfer;
pub use set_verification_key::SetVerificationKey;
pub use withdraw::Withdraw;

// Re-export admin account structs
pub use admin::pause::PausePool;
pub use admin::unpause::UnpausePool;
pub use admin::update_authority::UpdateAuthority;
