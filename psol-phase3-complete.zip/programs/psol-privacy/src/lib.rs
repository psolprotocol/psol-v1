//! pSol Privacy Pool - Phase 3 Production Implementation
//!
//! A ZK-based privacy pool for Solana using commitment/nullifier scheme
//! with Groth16 proof verification.
//!
//! # Phase 3 Features
//!
//! - **Off-chain commitment**: Users compute commitments using Poseidon off-chain
//! - **Full Groth16 verification**: Production-ready pairing-based verification
//! - **Private transfers**: 2-in-2-out transfers within the pool
//! - **Complete VK validation**: All curve points validated on BN254
//!
//! # Protocol Overview
//!
//! ```text
//! ┌─────────────┐     deposit      ┌──────────────┐     withdraw     ┌─────────────┐
//! │   Public    │ ───────────────► │   Shielded   │ ───────────────► │   Public    │
//! │   Tokens    │                  │     Pool     │                  │   Tokens    │
//! └─────────────┘                  └──────────────┘                  └─────────────┘
//!       │                                │                                  ▲
//!       │                                │                                  │
//!       └─ commitment inserted ──────────┴─ ZK proof verified ──────────────┘
//! ```
//!
//! # Core Concepts
//!
//! ## Commitments (Off-Chain Computation)
//!
//! Users compute commitments OFF-CHAIN using Poseidon:
//! ```text
//! commitment = Poseidon(secret, nullifier_preimage, amount)
//! ```
//!
//! This design:
//! - Avoids Solana BPF stack limitations
//! - Ensures exact circuit compatibility
//! - Keeps secrets completely off-chain
//!
//! ## Nullifiers
//!
//! Computed as: `nullifier_hash = Poseidon(nullifier_preimage, secret)`
//!
//! The nullifier is revealed on-chain during withdrawal to prevent double-spending.
//! Each nullifier can only be used once (enforced via PDAs).
//!
//! ## Zero-Knowledge Proofs
//!
//! Withdrawals and transfers require Groth16 proofs demonstrating:
//! 1. Knowledge of secrets for commitments in the tree
//! 2. Correct commitment computation
//! 3. Correct nullifier derivation
//! 4. Public inputs match the transaction
//!
//! # Protocol Flows
//!
//! ## Deposit Flow
//! ```text
//! 1. User generates (secret, nullifier_preimage) randomly off-chain
//! 2. User computes commitment = Poseidon(secret, nullifier_preimage, amount)
//! 3. User calls deposit(amount, commitment)
//! 4. On-chain:
//!    a. Transfer tokens from user to vault
//!    b. Insert commitment into Merkle tree
//!    c. Emit DepositEvent with leaf_index
//! 5. User saves (secret, nullifier_preimage, leaf_index) securely
//! ```
//!
//! ## Withdrawal Flow
//! ```text
//! 1. User fetches Merkle tree state to compute path
//! 2. User generates Groth16 proof with circuit
//! 3. User (or relayer) calls withdraw with proof
//! 4. On-chain:
//!    a. Verify merkle_root in history
//!    b. Verify nullifier not spent
//!    c. Verify Groth16 proof
//!    d. Mark nullifier as spent
//!    e. Transfer tokens
//! ```
//!
//! ## Private Transfer Flow
//! ```text
//! 1. User proves knowledge of 2 input commitments
//! 2. User provides 2 output commitments
//! 3. Circuit verifies: sum(inputs) = sum(outputs) + fee
//! 4. On-chain:
//!    a. Verify proof
//!    b. Mark 2 nullifiers spent
//!    c. Insert 2 new commitments
//!    d. Transfer fee if applicable
//! ```
//!
//! # Security Properties
//!
//! - **Hiding**: Deposits and withdrawals cannot be linked
//! - **Binding**: Users cannot claim more than deposited
//! - **Double-spend prevention**: Nullifiers can only be used once
//! - **Fail-closed**: Invalid proofs are always rejected
//!
//! # Account Structure
//!
//! - `PoolConfig`: Pool settings (PDA: ["pool", token_mint])
//! - `MerkleTree`: Commitment storage (PDA: ["merkle_tree", pool_config])
//! - `VerificationKeyAccount`: Groth16 VK (PDA: ["verification_key", pool_config])
//! - `SpentNullifier`: Per-nullifier marker (PDA: ["nullifier", pool_config, nullifier_hash])
//! - `Vault`: Token account (PDA: ["vault", pool_config])

use anchor_lang::prelude::*;

pub mod crypto;
pub mod error;
pub mod events;
pub mod instructions;
pub mod state;

#[cfg(test)]
mod tests;

use instructions::*;

// Program ID - Update after deployment
declare_id!("Ddokrq1M6hT9Vu63k4JWqVRSecyLeotNf8xKknKfRwvZ");

#[program]
pub mod psol_privacy {
    use super::*;

    /// Initialize a new privacy pool for a specific SPL token.
    ///
    /// Creates:
    /// - PoolConfig PDA (pool settings and authority)
    /// - MerkleTree PDA (commitment storage)
    /// - VerificationKey PDA (Groth16 VK storage)
    /// - Vault token account (holds deposited tokens)
    ///
    /// # Arguments
    /// * `tree_depth` - Merkle tree depth (4-24, recommended: 20 for ~1M leaves)
    /// * `root_history_size` - Number of historical roots (min: 30, recommended: 100+)
    pub fn initialize_pool(
        ctx: Context<InitializePool>,
        tree_depth: u8,
        root_history_size: u16,
    ) -> Result<()> {
        instructions::initialize_pool::handler(ctx, tree_depth, root_history_size)
    }

    /// Set or update the Groth16 verification key.
    ///
    /// The VK must come from a trusted setup ceremony.
    /// All points are validated to be on the BN254 curve.
    ///
    /// # Arguments
    /// * `vk_alpha_g1` - α point in G1 (64 bytes)
    /// * `vk_beta_g2` - β point in G2 (128 bytes)
    /// * `vk_gamma_g2` - γ point in G2 (128 bytes)
    /// * `vk_delta_g2` - δ point in G2 (128 bytes)
    /// * `vk_ic` - IC points in G1 (7 points for 6 public inputs)
    ///
    /// # Security
    /// - Only callable by pool authority
    /// - VK integrity is critical for security
    pub fn set_verification_key(
        ctx: Context<SetVerificationKey>,
        vk_alpha_g1: [u8; 64],
        vk_beta_g2: [u8; 128],
        vk_gamma_g2: [u8; 128],
        vk_delta_g2: [u8; 128],
        vk_ic: Vec<[u8; 64]>,
    ) -> Result<()> {
        instructions::set_verification_key::handler(
            ctx,
            vk_alpha_g1,
            vk_beta_g2,
            vk_gamma_g2,
            vk_delta_g2,
            vk_ic,
        )
    }

    /// Deposit tokens into the privacy pool.
    ///
    /// # Phase 3 Model
    /// The commitment is computed OFF-CHAIN by the user using Poseidon.
    /// This ensures circuit compatibility and avoids BPF stack limits.
    ///
    /// # Arguments
    /// * `amount` - Token amount to deposit (must be > 0)
    /// * `commitment` - Pre-computed commitment = Poseidon(secret, nullifier_preimage, amount)
    ///
    /// # Returns
    /// Emits DepositEvent with leaf_index needed for proofs.
    ///
    /// # Security
    /// - User must compute commitment correctly with matching Poseidon params
    /// - Invalid commitment = funds locked forever
    /// - User must save (secret, nullifier_preimage, leaf_index)
    pub fn deposit(
        ctx: Context<Deposit>,
        amount: u64,
        commitment: [u8; 32],
    ) -> Result<()> {
        instructions::deposit::handler(ctx, amount, commitment)
    }

    /// Withdraw tokens from the privacy pool using a ZK proof.
    ///
    /// # Arguments
    /// * `proof_data` - Serialized Groth16 proof (256 bytes)
    /// * `merkle_root` - Root to prove membership against
    /// * `nullifier_hash` - Hash of nullifier (prevents double-spend)
    /// * `recipient` - Address to receive tokens
    /// * `amount` - Amount to withdraw (before fee)
    /// * `relayer` - Relayer address (receives fee)
    /// * `relayer_fee` - Fee paid to relayer
    ///
    /// # Security
    /// - Full Groth16 verification is always performed
    /// - Invalid proofs are rejected
    #[allow(clippy::too_many_arguments)]
    pub fn withdraw(
        ctx: Context<Withdraw>,
        proof_data: Vec<u8>,
        merkle_root: [u8; 32],
        nullifier_hash: [u8; 32],
        recipient: Pubkey,
        amount: u64,
        relayer: Pubkey,
        relayer_fee: u64,
    ) -> Result<()> {
        instructions::withdraw::handler(
            ctx,
            proof_data,
            merkle_root,
            nullifier_hash,
            recipient,
            amount,
            relayer,
            relayer_fee,
        )
    }

    /// Private transfer within the pool (2-in-2-out).
    ///
    /// Transfers value between commitments without leaving the pool.
    /// Enables mixing, splitting, and consolidation of notes.
    ///
    /// # Arguments
    /// * `proof_data` - Groth16 proof for transfer circuit
    /// * `merkle_root` - Root for membership proofs
    /// * `nullifier_hash_0` - First input nullifier
    /// * `nullifier_hash_1` - Second input nullifier
    /// * `output_commitment_0` - First output commitment
    /// * `output_commitment_1` - Second output commitment
    /// * `fee` - Optional fee (0 for no fee)
    ///
    /// # Circuit Constraint
    /// sum(input_amounts) = sum(output_amounts) + fee
    #[allow(clippy::too_many_arguments)]
    pub fn private_transfer(
        ctx: Context<PrivateTransfer>,
        proof_data: Vec<u8>,
        merkle_root: [u8; 32],
        nullifier_hash_0: [u8; 32],
        nullifier_hash_1: [u8; 32],
        output_commitment_0: [u8; 32],
        output_commitment_1: [u8; 32],
        fee: u64,
    ) -> Result<()> {
        instructions::private_transfer::handler(
            ctx,
            proof_data,
            merkle_root,
            nullifier_hash_0,
            nullifier_hash_1,
            output_commitment_0,
            output_commitment_1,
            fee,
        )
    }

    // ========== Admin Instructions ==========

    /// Pause the pool (emergency stop).
    /// Blocks all deposits and withdrawals.
    /// Only callable by pool authority.
    pub fn pause_pool(ctx: Context<PausePool>) -> Result<()> {
        instructions::admin::pause::handler(ctx)
    }

    /// Unpause the pool.
    /// Only callable by pool authority.
    pub fn unpause_pool(ctx: Context<UnpausePool>) -> Result<()> {
        instructions::admin::unpause::handler(ctx)
    }

    /// Transfer pool authority to a new address.
    /// Only callable by current authority.
    pub fn update_authority(ctx: Context<UpdateAuthority>, new_authority: Pubkey) -> Result<()> {
        instructions::admin::update_authority::handler(ctx, new_authority)
    }
}
